#!/usr/bin/env bash
apt update; apt install -y python3-pip mpv libcaca-dev
pip3 install --upgrade youtube_dl
# Choose a video under creative commons
youtube-dl --recode-video mp4 --verbose \
           --user-agent "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)" \
           --output vid.mp4 \
           "https://www.youtube.com/watch?v=ZXsQAXx_ao0"
