#!/usr/bin/env bash
set -o xtrace




sudo snap remove --purge openstackclients
sudo snap remove --purge microstack
