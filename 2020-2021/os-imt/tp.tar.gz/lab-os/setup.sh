#!/usr/bin/env bash
set -o errexit
set -o xtrace

# Set the admin password to keystone
snap set microstack config.credentials.keystone-password=keystone
snap set microstack config.host.check-qemu=False

# Initialize  OpenStack
microstack.init --auto --control

# Make nova use qemu instead of qemu-kvm
# i.e,:
# > [libvirt]
# > virt_type = kvm             # rewrite to qemu
# > cpu_mode = host-passthrough # rewrite to host-model
NOVA_HYPERV_CONF=/var/snap/microstack/common/etc/nova/nova.conf.d/hypervisor.conf
sed -i 's|virt_type.\+|virt_type = qemu|' $NOVA_HYPERV_CONF
sed -i 's|cpu_mode.\+|cpu_mode = host-model|' $NOVA_HYPERV_CONF
snap restart microstack.nova-compute

# Install the bare necessities
apt install --yes --quiet silversearcher-ag curl tcpdump kmod vim htop
snap install --channel=latest/stable openstackclients --classic

# Put snap openstackclients into the path.
export PATH=/snap/bin:$PATH

set +o xtrace

# Remove icmp and tcp security group rules of `microstack.init --auto`
for rule in $(microstack.openstack security group rule list --protocol icmp -c ID -f value)
do
    microstack.openstack security group rule delete "${rule}"
done
for rule in $(microstack.openstack security group rule list --protocol tcp -c ID -f value)
do
    microstack.openstack security group rule delete "${rule}"
done

# Do not include this for IMT-A
# # Undo the external network setup of `microstack.init --auto`
# sysctl -w net.ipv4.ip_forward=0 > /dev/null
# extcidr=10.20.20.0/24  # find it with `sudo iptables -t nat -L`
# iptables -w -t nat -D POSTROUTING -s $extcidr ! -d $extcidr -j MASQUERADE > /dev/null
set -o xtrace
