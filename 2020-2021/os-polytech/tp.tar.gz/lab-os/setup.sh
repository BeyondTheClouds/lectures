#!/usr/bin/env bash
set -o errexit
set -o xtrace

# Install the bare necessities
apt install --yes --quiet silversearcher-ag curl tcpdump kmod vim htop lynx crudini
# On ubuntu 20.04 only
apt install --yes --quiet bat

# Set the admin password to keystone
snap set microstack config.credentials.keystone-password=keystone
snap set microstack config.host.check-qemu=True

# Initialize  OpenStack
microstack.init --auto --control



# Install openstack client
snap info openstackclients | fgrep -q installed && sudo snap remove --purge openstackclients
snap install --channel=latest/stable openstackclients --classic

# Put snap openstackclients into the path.
export PATH=/snap/bin:$PATH

set +o xtrace

# Remove icmp and tcp security group rules of `microstack.init --auto`
for rule in $(microstack.openstack security group rule list --protocol icmp -c ID -f value)
do
    microstack.openstack security group rule delete "${rule}"
done
for rule in $(microstack.openstack security group rule list --protocol tcp -c ID -f value)
do
    microstack.openstack security group rule delete "${rule}"
done


set -o xtrace
