#!/usr/bin/env bash
set -o xtrace

# Undo the external network setup of `microstack.init --auto`
sysctl -w net.ipv4.ip_forward=0 > /dev/null
extcidr=10.20.20.0/24  # find it with `sudo iptables -t nat -L`

# Flush the nat table
# iptables -w -t nat -D POSTROUTING -s $extcidr ! -d $extcidr -j MASQUERADE > /dev/null
iptables -Z
iptables -t nat -F
iptables -t nat -X
sudo apt remove --yes --quiet --autoremove heat-api heat-api-cfn heat-engine

sudo snap remove --purge openstackclients
sudo snap remove --purge microstack
