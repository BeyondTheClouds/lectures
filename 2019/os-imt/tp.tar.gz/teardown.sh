#!/usr/bin/env bash
. admin-openrc.sh



sudo snap remove openstackclients
sudo snap remove microstack
