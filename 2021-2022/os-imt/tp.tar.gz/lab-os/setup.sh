#!/usr/bin/env bash
set -o errexit
set -o xtrace

# Install the bare necessities
apt install --yes --quiet silversearcher-ag curl tcpdump kmod vim htop lynx crudini coreutils
# On ubuntu 20.04 only
apt install --yes --quiet bat

# Set the admin password to keystone
snap set microstack config.credentials.keystone-password=lab-os
snap set microstack config.host.check-qemu=True

# Initialize  OpenStack
microstack.init --auto --control

# Make nova use qemu instead of qemu-kvm
# i.e,:
# > [libvirt]
# > virt_type = kvm             # rewrite to qemu
# > cpu_mode = host-passthrough # rewrite to host-model
NOVA_HYPERV_CONF=/var/snap/microstack/common/etc/nova/nova.conf.d/hypervisor.conf
crudini --set $NOVA_HYPERV_CONF libvirt virt_type "qemu"
crudini --set $NOVA_HYPERV_CONF libvirt cpu_mode  "host-model"
snap restart microstack.nova-compute

# Install openstack client
snap info openstackclients | fgrep -q installed && sudo snap remove --purge openstackclients
snap install openstackclients --channel=ussuri/stable

# Put snap openstackclients into the path.
export PATH=/snap/bin:$PATH

set +o xtrace

# Remove icmp and tcp security group rules of `microstack.init --auto`
for rule in $(microstack.openstack security group rule list --protocol icmp -c ID -f value)
do
    microstack.openstack security group rule delete "${rule}"
done
for rule in $(microstack.openstack security group rule list --protocol tcp -c ID -f value)
do
    microstack.openstack security group rule delete "${rule}"
done

set -o xtrace
