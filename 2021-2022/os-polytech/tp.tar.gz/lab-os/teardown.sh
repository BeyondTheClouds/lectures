#!/usr/bin/env bash
set -o xtrace


sudo apt remove --yes --quiet --autoremove heat-api heat-api-cfn heat-engine

sudo snap remove --purge openstackclients
sudo snap remove --purge microstack
